# NotifyHub — WhatsApp Notification Platform

A Flask-powered WhatsApp notification hub using **Green API**. Built for churches, businesses, schools, and organisations to send smart automated notifications.

---

## Quick Start

```bash
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000 — login with **admin / admin123**

---

## Features

| Feature | Description |
|---|---|
| **Send Messages** | One-off or bulk WhatsApp messages |
| **Templates** | Reusable messages with `{{variables}}` |
| **AI Agents** | Auto-respond to incoming messages using Claude |
| **Field Mapper** | Map external data fields to template variables |
| **Webhooks** | Push events to external platforms |
| **REST API** | Integrate any platform via HTTP |
| **Contact Groups** | Tags, meta, CSV import |
| **Message Log** | Full inbox/outbox history |

---

## Setup Green API

1. Register at https://green-api.com (free tier available)
2. Create an instance & link your WhatsApp number
3. In **Settings → Green API**, enter your Instance ID and Token
4. Set the incoming webhook URL to: `http://YOUR_DOMAIN/api/incoming`

---

## REST API

### Send a message
```bash
curl -X POST http://localhost:5000/api/send \
  -H "X-API-Key: YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"phone": "+27821234567", "message": "Hello from NotifyHub!"}'
```

### Send with template + variables
```bash
curl -X POST http://localhost:5000/api/send \
  -H "X-API-Key: YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"phone": "+27821234567", "template_id": 1, "variables": {"name": "Sipho", "order_id": "ORD-123"}}'
```

### Add a contact
```bash
curl -X POST http://localhost:5000/api/contacts \
  -H "X-API-Key: YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name": "John", "phone": "+27821234567", "tags": ["member"]}'
```

---

## AI Agents

1. Add your Anthropic API key in Settings
2. Go to **AI Agents → New Agent**
3. Write instructions (system prompt) for the bot
4. Set trigger keywords (or leave blank to reply to everything)
5. Enable the agent — it will auto-reply to incoming WhatsApp messages

---

## Use Cases

- 📋 **Application Tracking** — notify applicants of status changes
- 📦 **Order Tracking** — delivery updates from your store
- 🗓 **Interview Scheduling** — confirm & remind candidates  
- ✅ **Booking Confirmations** — instant client notifications
- ⛪ **Church Notices** — events, service reminders, prayer calls

---

## Project Structure

```
whatsapp-notify/
├── app.py              # Flask app + all routes
├── notify.db           # SQLite database (auto-created)
├── requirements.txt
└── templates/
    ├── base.html       # Nav + layout shell
    ├── login.html
    ├── dashboard.html
    ├── contacts.html
    ├── templates.html
    ├── send.html
    ├── campaigns.html
    ├── messages.html
    ├── mapper.html
    ├── agents.html
    ├── webhooks.html
    └── settings.html
```
